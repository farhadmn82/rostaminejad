<?php header('Refresh:1; url=gallery.php');?>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
</head>

